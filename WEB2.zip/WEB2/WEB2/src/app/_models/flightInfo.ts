export class FlightInfo
{
   id:string;
   city1: string;
   city2: string;
   city1short: string;
   city2short: string;
   time1: string;
   time2: string;
   photo: string;
   flighttime: string;
   triptype: string;
   persons: string;
   class: string;
   price: string;
   date1:string;
   date2:string;
}