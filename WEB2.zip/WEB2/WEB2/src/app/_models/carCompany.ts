export interface CarCompany { 
    id: number, 
    promoDesc: string, 
    name: string, 
    photo: string,
    photoh: string,
    map: string,
    address: string,
    about: string,
    carB: string,
    carM: string,
    carP: string
    carB1: string,
    carM1: string,
    carP1: string
    carB2: string,
    carM2: string,
    carP2: string
    carB3: string,
    carM3: string,
    carP3: string
 

}