export class AvioCompany { 
    id: string;
    promoDesc: string;
    name: string;
    photo: string;
    photoh: string;
    map: string;
    address: string;
    about: string;



}