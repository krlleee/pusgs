export class ApplicationUser {
    id: string;
    name:string;
    lastName: string;
    username: string;
    password: string;
    email: string;
    phoneNumber: string;
    address: string;
    type: string;
}