import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myreservations',
  templateUrl: './myreservations.component.html',
  styleUrls: ['./myreservations.component.scss']
})
export class MyreservationsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
