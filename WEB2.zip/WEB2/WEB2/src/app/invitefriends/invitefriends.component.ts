import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-invitefriends',
  templateUrl: './invitefriends.component.html',
  styleUrls: ['./invitefriends.component.scss']
})
export class InvitefriendsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
