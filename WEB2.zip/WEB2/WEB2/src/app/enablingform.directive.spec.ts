import { EnablingformDirective } from './enablingform.directive';

describe('EnablingformDirective', () => {
  it('should create an instance', () => {
    const directive = new EnablingformDirective();
    expect(directive).toBeTruthy();
  });
});
