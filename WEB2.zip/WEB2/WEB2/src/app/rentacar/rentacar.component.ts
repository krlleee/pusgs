import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rentacar',
  templateUrl: './rentacar.component.html',
  styleUrls: ['./rentacar.component.scss']
})
export class RentacarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
