import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-reghome',
  templateUrl: './reghome.component.html',
  styleUrls: ['./reghome.component.scss']
})
export class ReghomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
